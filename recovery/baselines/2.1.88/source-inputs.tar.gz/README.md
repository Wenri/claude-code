# Claude Code 2.1.88 reconstructed compiler inputs

This archive contains the immutable6,067-file,51,618,606-byte input tree used by the verified reconstruction candidate. INPUT-MANIFEST.json records every path, byte count and SHA-256. The source manifest hash is66d84f48ee152785248d3ea4179f9588ce3ecdc54ca0294ab2732d820dec290f.

These are source/build inputs, not an executable distribution. Do not execute imported application sources. Preserve their copyright/license notices. Source contents, generated metadata and original-authorship claims are separate. The compiler profile, generated SDK declaration facades and frozen naming recipe are separate artifacts.

Safely extract only regular files under inputs/ and verify every manifest entry. Reject absolute paths, parent traversal, symlinks, hardlinks and unlisted payloads. Match the exact input manifest before compiling.
